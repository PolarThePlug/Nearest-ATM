-- CREATED BY POLAR THE PLUG
-- DISCORD https://discord.gg/PjNgP4tAv9
-- TEBEX https://www.polartheplug.com/

fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Polar The Plug'
description 'ATM Finder'
version '1.0'

client_scripts {
    'config.lua',
    'client.lua'
}
server_script 'server.lua'
