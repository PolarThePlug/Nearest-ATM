-- Register the customizable command from the config
RegisterCommand(Config.ATMCommand, function(source, args, rawCommand)
    TriggerClientEvent("findatm", source)
end, false)