RegisterNetEvent('findatm')
AddEventHandler('findatm', function()
    local playerCoords = GetEntityCoords(PlayerPedId())
    local closestATM = nil
    local closestDistance = -1

    -- Find the closest ATM from the list in config.lua
    for _, atmCoord in pairs(Config.ATMLocations) do
        local distance = #(playerCoords - vector3(atmCoord.x, atmCoord.y, atmCoord.z))

        if closestDistance == -1 or distance < closestDistance then
            closestATM = atmCoord
            closestDistance = distance
        end
    end

    if closestATM then
        -- Set GPS route to the closest ATM
        SetNewWaypoint(vector3(closestATM.x, closestATM.y, closestATM.z))
    else
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"ATM Finder", "No ATMs found!"}
        })
    end
end)
